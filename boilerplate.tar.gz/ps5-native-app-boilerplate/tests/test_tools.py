#!/usr/bin/env python3
# ps5-native-app-boilerplate - Host tooling regression tests.
# Copyright (C) 2026 BlackBearReloaded
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Exercises identity initialization and deployment resolution without a console.

import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]


class ToolTests(unittest.TestCase):
    def run_init(self, param, **values):
        environment = os.environ.copy()
        environment.update(values)
        return subprocess.run(
            ["bash", str(ROOT / "tools/init-project.sh"), str(param)],
            cwd=ROOT,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )

    def test_init_coordinates_media_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            param = Path(directory) / "param.json"
            param.write_text(
                json.dumps(
                    {
                        "contentId": "UP9000-PPSA99999_00-HELLOWORLD000001",
                        "localizedParameters": {
                            "defaultLanguage": "en-US",
                            "en-US": {"titleName": "Old"},
                        },
                        "gameIntent": {"permittedIntents": [{"intentType": "launchActivity"}]},
                    }
                ),
                encoding="utf-8",
            )
            result = self.run_init(
                param,
                TITLE_ID="PPSA12345",
                APP_NAME="Moon Client",
                APP_CATEGORY="media",
                CONTENT_SUFFIX="MOONCLIENT000001",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            configured = json.loads(param.read_text(encoding="utf-8"))
            self.assertEqual(configured["titleId"], "PPSA12345")
            self.assertEqual(configured["conceptId"], "12345")
            self.assertEqual(configured["contentId"], "UP9000-PPSA12345_00-MOONCLIENT000001")
            self.assertEqual(configured["localizedParameters"]["en-US"]["titleName"], "Moon Client")
            self.assertEqual(configured["applicationCategoryType"], 65536)
            self.assertEqual(configured["contentBadgeType"], 2)
            self.assertNotIn("gameIntent", configured)

    def test_init_rejects_invalid_title_without_rewriting(self):
        with tempfile.TemporaryDirectory() as directory:
            param = Path(directory) / "param.json"
            original = '{"contentId":"UP9000-PPSA99999_00-HELLOWORLD000001"}\n'
            param.write_text(original, encoding="utf-8")
            result = self.run_init(param, TITLE_ID="PPSA12", APP_NAME="Broken")
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(param.read_text(encoding="utf-8"), original)

    def test_init_derives_game_suffix_and_preserves_mode(self):
        with tempfile.TemporaryDirectory() as directory:
            param = Path(directory) / "param.json"
            param.write_text(
                json.dumps(
                    {
                        "contentId": "UP9000-PPSA99999_00-HELLOWORLD000001",
                        "localizedParameters": {
                            "defaultLanguage": "en-US",
                            "en-US": {"titleName": "Old"},
                        },
                    }
                ),
                encoding="utf-8",
            )
            param.chmod(0o640)
            result = self.run_init(
                param, TITLE_ID="PPSA54321", APP_NAME="Native Sample", CONTENT_SUFFIX=""
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            configured = json.loads(param.read_text(encoding="utf-8"))
            self.assertEqual(configured["contentId"], "UP9000-PPSA54321_00-NATIVESAMPLE0000")
            self.assertEqual(configured["applicationCategoryType"], 0)
            self.assertEqual(configured["contentBadgeType"], 1)
            self.assertEqual(
                configured["gameIntent"]["permittedIntents"],
                [{"intentType": "launchActivity"}],
            )
            self.assertEqual(param.stat().st_mode & 0o777, 0o640)

    def test_undeploy_dry_run_resolves_only_current_title(self):
        environment = os.environ.copy()
        environment.update(PS5_HOST="192.0.2.1", DEPLOY_DRY_RUN="1")
        result = subprocess.run(
            ["bash", str(ROOT / "tools/deploy.sh"), "undeploy"],
            cwd=ROOT,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("/data/homebrew/PPSA99999/", result.stdout)
        self.assertIn("PPSA99999.{ffpkg,ffpfsc}", result.stdout)
        self.assertIn("no network request was sent", result.stdout)

    def test_deploy_dry_run_uses_mocked_build_and_no_network(self):
        with tempfile.TemporaryDirectory() as directory:
            sandbox = Path(directory)
            (sandbox / "tools").mkdir()
            (sandbox / "sce_sys").mkdir()
            shutil.copy2(ROOT / "tools/deploy.sh", sandbox / "tools/deploy.sh")
            (sandbox / "sce_sys/param.json").write_text(
                '{"titleId":"PPSA12345"}\n', encoding="utf-8"
            )

            mock_bin = sandbox / "mock-bin"
            mock_bin.mkdir()
            mock_make = mock_bin / "make"
            mock_make.write_text(
                "#!/usr/bin/env bash\n"
                "mkdir -p \"$MOCK_ROOT/dist\"\n"
                "printf '%s\\n' \"$*\" > \"$MOCK_ROOT/make-arguments\"\n"
                "mkdir -p \"$MOCK_ROOT/dist/PPSA12345/sce_sys\"\n"
                "printf app > \"$MOCK_ROOT/dist/PPSA12345/eboot.bin\"\n"
                "printf '{}' > \"$MOCK_ROOT/dist/PPSA12345/sce_sys/param.json\"\n",
                encoding="utf-8",
            )
            mock_make.chmod(0o755)

            environment = os.environ.copy()
            environment.update(
                PS5_HOST="192.0.2.1",
                DEPLOY_DRY_RUN="1",
                MOCK_ROOT=str(sandbox),
                PATH=f"{mock_bin}{os.pathsep}{environment['PATH']}",
            )
            result = subprocess.run(
                ["bash", str(sandbox / "tools/deploy.sh")],
                cwd=sandbox,
                env=environment,
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("/data/homebrew/PPSA12345/\n", result.stdout)
            self.assertIn("Would publish 2 files", result.stdout)
            self.assertIn("no network request was sent", result.stdout)
            # The build asked for is the app folder, never an image.
            arguments = sandbox / "make-arguments"
            self.assertEqual(arguments.read_text(encoding="utf-8").split()[-1], "app")

            # An image format is refused before anything is built.
            arguments.unlink()
            environment["DEPLOY_FORMAT"] = "ffpkg"
            refused = subprocess.run(
                ["bash", str(sandbox / "tools/deploy.sh")],
                cwd=sandbox,
                env=environment,
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(refused.returncode, 2, refused.stdout)
            self.assertIn("DEPLOY_FORMAT is no longer used", refused.stderr)
            self.assertFalse(arguments.exists())

    def test_deploy_uses_selected_app_param_title(self):
        with tempfile.TemporaryDirectory() as directory:
            sandbox = Path(directory)
            (sandbox / "tools").mkdir()
            (sandbox / "sce_sys").mkdir()
            (sandbox / "examples/demo/sce_sys").mkdir(parents=True)
            shutil.copy2(ROOT / "tools/deploy.sh", sandbox / "tools/deploy.sh")
            (sandbox / "sce_sys/param.json").write_text(
                '{"titleId":"PPSA12345"}\n', encoding="utf-8"
            )
            selected_param = sandbox / "examples/demo/sce_sys/param.json"
            selected_param.write_text(
                '{"titleId":"PPSA54321"}\n', encoding="utf-8"
            )

            environment = os.environ.copy()
            environment.update(
                PS5_HOST="192.0.2.1",
                DEPLOY_DRY_RUN="1",
                APP_PARAM="examples/demo/sce_sys/param.json",
            )
            result = subprocess.run(
                ["bash", str(sandbox / "tools/deploy.sh"), "undeploy"],
                cwd=sandbox,
                env=environment,
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("/data/homebrew/PPSA54321/", result.stdout)
            self.assertNotIn("/data/homebrew/PPSA12345/", result.stdout)

    def test_pull_request_builds_are_named_and_labelled(self):
        workflow = (ROOT / ".github/workflows/tooling.yml").read_text(encoding="utf-8")
        self.assertIn(
            'echo "artifact=${GITHUB_REPOSITORY##*/}-PR$PR_NUMBER-$short" >> "$GITHUB_OUTPUT"',
            workflow,
        )
        self.assertIn('echo "BUILD_LABEL=PR $PR_NUMBER, $short" >> "$GITHUB_ENV"', workflow)
        self.assertIn("name: ${{ steps.label.outputs.artifact }}", workflow)
        # The release job still finds a tag's build under its commit.
        self.assertIn('--name "ps5-native-app-boilerplate-$GITHUB_SHA"', workflow)
        self.assertIn(
            'echo "artifact=ps5-native-app-boilerplate-$GITHUB_SHA" >> "$GITHUB_OUTPUT"', workflow
        )
        # A contributor's code is never built with write access or secrets.
        self.assertNotIn("pull_request_target:", workflow)
        build = (ROOT / "tools/build.sh").read_text(encoding="utf-8")
        self.assertIn('> "$app/build-label.txt"', build)
        self.assertIn("{1,40}$", build)
        self.assertLess(build.index("BUILD_LABEL must be"), build.index("ninja_run\n\napp="))
        self.assertIn('"/app0/build-label.txt"', (ROOT / "src/main.cpp").read_text())

    def test_automation_builds_the_zip_only(self):
        workflow = (ROOT / ".github/workflows/tooling.yml").read_text(encoding="utf-8")
        # The image formats are gone: nothing that builds may name them or their tools again.
        build_files = (
            ".github/workflows/tooling.yml",
            "Makefile",
            "build.ps1",
            "tools/build.sh",
        )
        for name in build_files:
            text = (ROOT / name).read_text(encoding="utf-8").lower()
            for gone in ("ffpfsc", "mkpfs", "ffpkg", "ufs2"):
                self.assertNotIn(gone, text, name)
        for name in (
            "setup-mkpfs-tooling.ps1",
            "setup-ffpkg-tooling.ps1",
            "setup-packaging-dependencies.sh",
        ):
            self.assertFalse((ROOT / "tools" / name).exists(), name)
        self.assertIn("run: make app", workflow)
        self.assertIn('sha256sum "$TITLE_ID.zip" > SHA256SUMS', workflow)
        self.assertIn('assets=("release/$FOLDER_ZIP" "release/$CHECKSUM")', workflow)
        # The release job creates a release, or fills one that has no ZIP; it never replaces,
        # deletes or rewrites anything on a release that exists.
        for forbidden in ("--clobber", "delete-asset", "gh release edit"):
            self.assertNotIn(forbidden, workflow)
        publish = workflow[workflow.index("- name: Publish GitHub release") :]
        self.assertIn('gh release create "$TAG" ', publish)
        self.assertIn('gh release upload "$TAG" ', publish)
        self.assertIn("--json assets --jq '.assets[].name'", publish)
        self.assertIn("if [[ $name == *.zip ]]; then", publish)
        self.assertIn("::warning title=Release files not from this run::", publish)
        self.assertLess(publish.index("gh release create"), publish.index("::warning"))
        self.assertLess(publish.index("::warning"), publish.index("gh release upload"))
        # The finished ZIP, and only the ZIP, is attested before it is uploaded: pinned action,
        # never for a pull request or in a private repository.
        attest = workflow.index("- name: Attest the release ZIP")
        upload = workflow.index("- name: Upload build")
        self.assertLess(workflow.index("- name: Write release checksums"), attest)
        self.assertLess(attest, upload)
        step = workflow[attest:upload]
        self.assertIn(
            "uses: actions/attest@1e69f48acb82d1966a394da916b4c1698aa569d6 # v4.2.2", step
        )
        self.assertIn(
            "if: github.event_name != 'pull_request' && !github.event.repository.private", step
        )
        self.assertIn("subject-path: dist/${{ env.TITLE_ID }}.zip\n", step)
        self.assertNotIn("SHA256SUMS", step)
        build_job = workflow[workflow.index("\n  build:") : workflow.index("\n  release:")]
        for permission in ("contents: read", "id-token: write", "attestations: write"):
            self.assertIn(f"      {permission}\n", build_job)
        self.assertNotIn("id-token", workflow.replace(build_job, ""))
        # Asked for by name, the removed formats are refused before anything is built.
        for removed in ("Ffpkg", "Ffpfsc", "All"):
            result = subprocess.run(
                ["bash", str(ROOT / "tools/build.sh"), removed],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(result.returncode, 2, removed)
            self.assertIn("usage: tools/build.sh [Folder]", result.stderr)

    def test_native_writer_anchors_relro_and_checks_load_congruence(self):
        source = (ROOT / "tooling/native/sce_module_writer.cpp").read_text(
            encoding="utf-8"
        )
        # RELRO is anchored at its first section: .data.rel.ro whenever lld
        # keeps it, otherwise the GOT, so a program without relocated
        # read-only data still converts.
        self.assertIn("relro_origin(image, relro_start)", source)
        self.assertIn('if (input.name == ".data.rel.ro")', source)
        self.assertIn("relro_source.file_offset", source)
        self.assertIn(
            "header.offset % header.alignment == header.address % header.alignment",
            source,
        )
        self.assertNotIn("const std::uint64_t relro_file = got.file_offset", source)


if __name__ == "__main__":
    unittest.main()
